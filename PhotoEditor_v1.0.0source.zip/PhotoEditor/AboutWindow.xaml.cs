using System;
using System.Diagnostics;
using System.Windows;
using PhotoEditor.Services;

namespace PhotoEditor
{
    public partial class AboutWindow : Window
    {
        private LanguageService _languageService;

        public AboutWindow(LanguageService languageService)
        {
            InitializeComponent();
            _languageService = languageService;
            UpdateTexts();
        }

        private void UpdateTexts()
        {
            var texts = _languageService.GetTexts();
            
            DeveloperText.Text = texts.Developer;
            FreeText.Text = texts.FreeText;
            OpenSourceText.Text = texts.OpenSourceText;
            CloseButtonText.Content = texts.CloseButton;
        }

        private void TelegramButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://t.me/El_bahram",
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private void YouTubeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://www.youtube.com/@El_bahram",
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private void GameChannelButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://www.youtube.com/@Elbahrambaba",
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
