using System;
using System.Windows;
using PhotoEditor.Services;

namespace PhotoEditor
{
    public partial class DonationWindow : Window
    {
        private LanguageService _languageService;

        public DonationWindow(LanguageService languageService)
        {
            InitializeComponent();
            _languageService = languageService;
            UpdateTexts();
        }

        private void UpdateTexts()
        {
            var texts = _languageService.GetTexts();
            
            DonationTitleText.Text = texts.DonationTitle;
            LitecoinLabelText.Text = texts.LitecoinLabel;
            BtcBep20LabelText.Text = texts.BtcBep20Label;
            CopyLtcButton.Content = texts.CopyButton;
            CopyBtcButton.Content = texts.CopyButton;
            CloseButtonText.Content = texts.CloseButton;
        }

        private void CopyLtcButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Clipboard.SetText("LbUg7FHcdqh6WzmsEWjaGPVBbga2RHvUyT");
                MessageBox.Show(_languageService.GetTexts().CopiedMessage, "Success", 
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch { }
        }

        private void CopyBtcButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Clipboard.SetText("0x3fa0982c13522a44ce39439c65501f900408c032");
                MessageBox.Show(_languageService.GetTexts().CopiedMessage, "Success", 
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch { }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
