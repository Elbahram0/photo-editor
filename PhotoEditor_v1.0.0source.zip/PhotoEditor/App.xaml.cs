using System.Windows;

namespace PhotoEditor
{
    public partial class App : Application
    {
    }
}
