using System;
using System.IO;
using Newtonsoft.Json;
using PhotoEditor.Models;

namespace PhotoEditor.Services
{
    public class LanguageService
    {
        private LanguageTexts _currentTexts;
        private string _currentLanguage = "tr";

        public LanguageService()
        {
            SetLanguage("tr");
        }

        public void SetLanguage(string languageCode)
        {
            _currentLanguage = languageCode;
            LoadLanguageFile(languageCode);
        }

        public string GetCurrentLanguage()
        {
            return _currentLanguage;
        }

        private void LoadLanguageFile(string languageCode)
        {
            try
            {
                string basePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath = Path.Combine(basePath, "Languages", $"{languageCode}.json");

                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);
                    _currentTexts = JsonConvert.DeserializeObject<LanguageTexts>(json);
                }
                else
                {
                    _currentTexts = GetDefaultTexts();
                }
            }
            catch
            {
                _currentTexts = GetDefaultTexts();
            }
        }

        public LanguageTexts GetTexts()
        {
            return _currentTexts ?? GetDefaultTexts();
        }

        private LanguageTexts GetDefaultTexts()
        {
            return new LanguageTexts
            {
                DropZone = "Fotoğrafları buraya sürükleyin veya tıklayın",
                Browse = "Gözat",
                FileInfo = "Dosya Bilgileri",
                FileCount = "Dosya Sayısı:",
                Format = "Format:",
                FileSize = "Toplam Boyut:",
                Dimensions = "Boyutlar:",
                NewFileName = "Yeni Dosya Adı:",
                Resize = "Boyutlandırma:",
                Width = "Genişlik (px):",
                Height = "Yükseklik (px):",
                ConvertTo = "Dönüştür:",
                Start = "Başlat",
                OpenFolder = "Build Klasörünü Aç",
                About = "Bilgilendirme",
                Success = "İşlem başarıyla tamamlandı!",
                FilesProcessed = "dosya işlendi!",
                InvalidFile = "Geçersiz dosya formatı!",
                Developer = "Geliştirici",
                FreeText = "Tamamen Bedavadır",
                OpenSourceText = "Açık Kaynak Kodludur",
                CloseButton = "Kapat"
            };
        }
    }
}
