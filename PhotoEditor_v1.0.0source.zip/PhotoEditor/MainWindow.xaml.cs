using System;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using System.Diagnostics;
using PhotoEditor.Services;
using PhotoEditor.Models;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using System.Windows.Controls;

namespace PhotoEditor
{
    public partial class MainWindow : Window
    {
        private LanguageService _languageService;
        private List<string> _selectedImages;
        private string _buildFolder;

        public MainWindow()
        {
            InitializeComponent();
            InitializeApp();
        }

        private void InitializeApp()
        {
            _languageService = new LanguageService();
            _selectedImages = new List<string>();
            _buildFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Build");
            
            if (!Directory.Exists(_buildFolder))
                Directory.CreateDirectory(_buildFolder);

            LoadLanguages();
            LoadFormatOptions();
            UpdateUIText();
        }

        private void LoadLanguages()
        {
            var trItem = new System.Windows.Controls.ComboBoxItem();
            trItem.Content = "Türkçe";
            trItem.Tag = "tr";
            
            var enItem = new System.Windows.Controls.ComboBoxItem();
            enItem.Content = "English";
            enItem.Tag = "en";
            
            LanguageComboBox.Items.Add(trItem);
            LanguageComboBox.Items.Add(enItem);
            LanguageComboBox.SelectedIndex = 0;
        }

        private void LoadFormatOptions()
        {
            FormatComboBox.Items.Add("PNG");
            FormatComboBox.Items.Add("JPG");
            FormatComboBox.Items.Add("JPEG");
            FormatComboBox.Items.Add("WEBP");
            FormatComboBox.Items.Add("BMP");
            FormatComboBox.Items.Add("GIF");
            FormatComboBox.Items.Add("TIFF");
            FormatComboBox.Items.Add("TIF");
            FormatComboBox.Items.Add("ICO");
            FormatComboBox.Items.Add("JFIF");
            FormatComboBox.Items.Add("HEIC");
            FormatComboBox.Items.Add("HEIF");
            FormatComboBox.Items.Add("AVIF");
            FormatComboBox.Items.Add("DNG");
            FormatComboBox.Items.Add("CR2");
            FormatComboBox.Items.Add("CR3");
            FormatComboBox.Items.Add("NEF");
            FormatComboBox.Items.Add("ARW");
            FormatComboBox.Items.Add("ORF");
            FormatComboBox.Items.Add("RW2");
            FormatComboBox.SelectedIndex = 0;
        }

        private void LanguageComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (LanguageComboBox.SelectedItem is System.Windows.Controls.ComboBoxItem item)
            {
                string lang = item.Tag.ToString();
                _languageService.SetLanguage(lang);
                UpdateUIText();
            }
        }

        private void UpdateUIText()
        {
            var texts = _languageService.GetTexts();
            DropZoneText.Text = texts.DropZone;
            BrowseButton.Content = texts.Browse;
            InfoTitle.Text = texts.FileInfo;
            FileCountLabel.Text = texts.FileCount;
            FormatLabel.Text = texts.Format;
            SizeLabel.Text = texts.FileSize;
            DimensionsLabel.Text = texts.Dimensions;
            ConvertToLabel.Text = texts.ConvertTo;
            NewFileNameLabel.Text = texts.NewFileName;
            ResizeLabel.Text = texts.Resize;
            WidthLabel.Text = texts.Width;
            HeightLabel.Text = texts.Height;
            ProcessButton.Content = texts.Start;
            OpenFolderButton.Content = texts.OpenFolder;
            DonationButton.Content = texts.Donation;
            AboutButton.Content = texts.About;
        }

        private void DonationButton_Click(object sender, RoutedEventArgs e)
        {
            var donationWindow = new DonationWindow(_languageService);
            donationWindow.ShowDialog();
        }

        private void AboutButton_Click(object sender, RoutedEventArgs e)
        {
            var aboutWindow = new AboutWindow(_languageService);
            aboutWindow.ShowDialog();
        }

        private void TelegramLink_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://t.me/El_bahram",
                    UseShellExecute = true
                });
            }
            catch { }
        }

        private void Window_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
            else
            {
                e.Effects = DragDropEffects.None;
            }
            e.Handled = true;
        }

        private void Window_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                LoadImages(files);
            }
        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "All Images|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tiff;*.tif;*.webp;*.ico;*.jfif;*.heic;*.heif;*.avif;*.dng;*.cr2;*.cr3;*.nef;*.arw;*.orf;*.rw2|" +
                         "Common (JPG,PNG,BMP,GIF,WEBP)|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.webp|" +
                         "RAW Formats (DNG,CR2,NEF,ARW)|*.dng;*.cr2;*.cr3;*.nef;*.arw;*.orf;*.rw2|" +
                         "All Files|*.*",
                Title = "Select Images",
                Multiselect = true
            };

            if (dialog.ShowDialog() == true)
            {
                LoadImages(dialog.FileNames);
            }
        }

        private void LoadImages(string[] filePaths)
        {
            try
            {
                _selectedImages.Clear();
                PreviewPanel.Children.Clear();
                
                foreach (var filePath in filePaths)
                {
                    if (IsImageFile(filePath))
                    {
                        _selectedImages.Add(filePath);
                    }
                }

                if (_selectedImages.Count == 0)
                {
                    MessageBox.Show(_languageService.GetTexts().InvalidFile, "Error", 
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                BitmapImage firstBitmap = null;
                
                foreach (var imagePath in _selectedImages)
                {
                    BitmapImage bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.DecodePixelWidth = 250;
                    bitmap.UriSource = new Uri(imagePath);
                    bitmap.EndInit();
                    
                    if (firstBitmap == null)
                        firstBitmap = bitmap;

                    var border = new System.Windows.Controls.Border
                    {
                        Width = 250,
                        Height = 200,
                        Margin = new Thickness(10),
                        BorderBrush = System.Windows.Media.Brushes.Transparent,
                        BorderThickness = new Thickness(3),
                        CornerRadius = new System.Windows.CornerRadius(10),
                        Background = new System.Windows.Media.SolidColorBrush(
                            System.Windows.Media.Color.FromRgb(42, 42, 62))
                    };

                    var stackPanel = new System.Windows.Controls.StackPanel();
                    
                    var image = new System.Windows.Controls.Image
                    {
                        Source = bitmap,
                        Stretch = System.Windows.Media.Stretch.Uniform,
                        Height = 160,
                        Margin = new Thickness(5)
                    };

                    var fileName = new System.Windows.Controls.TextBlock
                    {
                        Text = Path.GetFileName(imagePath),
                        Foreground = System.Windows.Media.Brushes.White,
                        FontSize = 11,
                        TextAlignment = TextAlignment.Center,
                        TextTrimming = TextTrimming.CharacterEllipsis,
                        Margin = new Thickness(5, 0, 5, 5)
                    };

                    stackPanel.Children.Add(image);
                    stackPanel.Children.Add(fileName);
                    border.Child = stackPanel;
                    
                    PreviewPanel.Children.Add(border);
                }

                PreviewScrollViewer.Visibility = Visibility.Visible;
                DropZonePanel.Visibility = Visibility.Collapsed;

                DisplayImagesInfo(firstBitmap);
                ProcessButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading images: {ex.Message}", "Error", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsImageFile(string filePath)
        {
            string[] validExtensions = { ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tiff", ".webp", ".ico" };
            string ext = Path.GetExtension(filePath).ToLower();
            return Array.Exists(validExtensions, e => e == ext);
        }

        private void DisplayImagesInfo(BitmapImage firstBitmap)
        {
            FileCountValue.Text = $"{_selectedImages.Count} {(_selectedImages.Count == 1 ? "file" : "files")}";
            
            if (_selectedImages.Count == 1)
            {
                FileInfo fileInfo = new FileInfo(_selectedImages[0]);
                FormatValue.Text = Path.GetExtension(_selectedImages[0]).ToUpper().TrimStart('.');
                SizeValue.Text = FormatFileSize(fileInfo.Length);
                NewFileNameTextBox.Text = Path.GetFileNameWithoutExtension(_selectedImages[0]);
            }
            else
            {
                var formats = _selectedImages.Select(f => Path.GetExtension(f).ToUpper().TrimStart('.')).Distinct();
                FormatValue.Text = string.Join(", ", formats);
                
                long totalSize = _selectedImages.Sum(f => new FileInfo(f).Length);
                SizeValue.Text = FormatFileSize(totalSize);
                
                NewFileNameTextBox.Text = "batch_converted";
            }
            
            DimensionsValue.Text = $"{firstBitmap.PixelWidth} x {firstBitmap.PixelHeight} px";
            WidthTextBox.Text = firstBitmap.PixelWidth.ToString();
            HeightTextBox.Text = firstBitmap.PixelHeight.ToString();

            InfoPanel.Visibility = Visibility.Visible;
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;
            
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }

            return $"{len:0.##} {sizes[order]}";
        }

        private void ProcessButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedImages == null || _selectedImages.Count == 0)
                return;

            try
            {
                string selectedFormat = FormatComboBox.SelectedItem.ToString().ToLowerInvariant();
                int targetWidth = int.TryParse(WidthTextBox.Text, out int w) ? w : 0;
                int targetHeight = int.TryParse(HeightTextBox.Text, out int h) ? h : 0;
                
                int processedCount = 0;
                
                foreach (var imagePath in _selectedImages)
                {
                    BitmapImage source = new BitmapImage(new Uri(imagePath));
                    
                    int finalWidth = targetWidth > 0 ? targetWidth : source.PixelWidth;
                    int finalHeight = targetHeight > 0 ? targetHeight : source.PixelHeight;
                    
                    string baseFileName = _selectedImages.Count == 1 
                        ? (string.IsNullOrWhiteSpace(NewFileNameTextBox.Text) 
                            ? Path.GetFileNameWithoutExtension(imagePath) 
                            : NewFileNameTextBox.Text)
                        : $"{NewFileNameTextBox.Text}_{processedCount + 1}";
                    
                    string outputPath = Path.Combine(_buildFolder, $"{baseFileName}.{selectedFormat}");
                    
                    TransformedBitmap resizedBitmap = new TransformedBitmap(source, 
                        new System.Windows.Media.ScaleTransform(
                            (double)finalWidth / source.PixelWidth,
                            (double)finalHeight / source.PixelHeight));

                    if (selectedFormat == "ico")
                    {
                        // ICO için özel işlem
                        string tempPng = Path.Combine(_buildFolder, $"{baseFileName}_temp_{processedCount}.png");
                        var pngEncoder = new PngBitmapEncoder();
                        pngEncoder.Frames.Add(BitmapFrame.Create(resizedBitmap));
                        using (FileStream stream = new FileStream(tempPng, FileMode.Create))
                        {
                            pngEncoder.Save(stream);
                        }
                        
                        System.Threading.Thread.Sleep(100); // Dosyanın serbest bırakılmasını bekle
                        ConvertToIco(tempPng, outputPath);
                        
                        try
                        {
                            System.Threading.Thread.Sleep(100);
                            if (File.Exists(tempPng))
                                File.Delete(tempPng);
                        }
                        catch { }
                    }
                    else
                    {
                        BitmapEncoder encoder = GetEncoder(selectedFormat);
                        encoder.Frames.Add(BitmapFrame.Create(resizedBitmap));

                        using (FileStream stream = new FileStream(outputPath, FileMode.Create))
                        {
                            encoder.Save(stream);
                        }
                    }
                    
                    processedCount++;
                }

                var successMsg = _selectedImages.Count == 1 
                    ? _languageService.GetTexts().Success 
                    : $"{processedCount} {_languageService.GetTexts().FilesProcessed}";
                
                MessageBox.Show(successMsg, "Success", 
                    MessageBoxButton.OK, MessageBoxImage.Information);

                Process.Start("explorer.exe", _buildFolder);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private BitmapEncoder GetEncoder(string format)
        {
            return format switch
            {
                "png" => new PngBitmapEncoder(),
                "jpg" or "jpeg" or "jfif" => new JpegBitmapEncoder { QualityLevel = 95 },
                "webp" or "avif" => new WmpBitmapEncoder(),
                "bmp" => new BmpBitmapEncoder(),
                "gif" => new GifBitmapEncoder(),
                "tiff" or "tif" => new TiffBitmapEncoder(),
                "ico" => new PngBitmapEncoder(),
                _ => new PngBitmapEncoder()
            };
        }

        private void ConvertToIco(string pngPath, string icoPath)
        {
            try
            {
                // PNG'yi yükle
                var bitmap = new BitmapImage(new Uri(pngPath));
                
                // ICO için birden fazla boyut oluştur (16, 32, 48, 256)
                int[] sizes = { 16, 32, 48, 256 };
                
                using (var fileStream = new FileStream(icoPath, FileMode.Create))
                using (var writer = new BinaryWriter(fileStream))
                {
                    // ICO header
                    writer.Write((short)0); // Reserved
                    writer.Write((short)1); // Type (1 = ICO)
                    writer.Write((short)sizes.Length); // Number of images
                    
                    int offset = 6 + (16 * sizes.Length); // Header + directory entries
                    
                    var imageData = new List<byte[]>();
                    
                    // Her boyut için PNG verisi oluştur
                    foreach (var size in sizes)
                    {
                        var resized = new TransformedBitmap(bitmap, 
                            new System.Windows.Media.ScaleTransform(
                                (double)size / bitmap.PixelWidth,
                                (double)size / bitmap.PixelHeight));
                        
                        var encoder = new PngBitmapEncoder();
                        encoder.Frames.Add(BitmapFrame.Create(resized));
                        
                        using (var ms = new MemoryStream())
                        {
                            encoder.Save(ms);
                            var data = ms.ToArray();
                            imageData.Add(data);
                            
                            // ICO directory entry
                            writer.Write((byte)(size == 256 ? 0 : size)); // Width
                            writer.Write((byte)(size == 256 ? 0 : size)); // Height
                            writer.Write((byte)0); // Color palette
                            writer.Write((byte)0); // Reserved
                            writer.Write((short)1); // Color planes
                            writer.Write((short)32); // Bits per pixel
                            writer.Write(data.Length); // Size of image data
                            writer.Write(offset); // Offset to image data
                            
                            offset += data.Length;
                        }
                    }
                    
                    // PNG verilerini yaz
                    foreach (var data in imageData)
                    {
                        writer.Write(data);
                    }
                }
            }
            catch { }
        }

        private void OpenFolderButton_Click(object sender, RoutedEventArgs e)
        {
            if (Directory.Exists(_buildFolder))
            {
                Process.Start("explorer.exe", _buildFolder);
            }
        }
    }
}
