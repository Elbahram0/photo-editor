namespace PhotoEditor.Models
{
    public class LanguageTexts
    {
        public string DropZone { get; set; }
        public string Browse { get; set; }
        public string FileInfo { get; set; }
        public string FileCount { get; set; }
        public string Format { get; set; }
        public string FileSize { get; set; }
        public string Dimensions { get; set; }
        public string NewFileName { get; set; }
        public string Resize { get; set; }
        public string Width { get; set; }
        public string Height { get; set; }
        public string ConvertTo { get; set; }
        public string Start { get; set; }
        public string OpenFolder { get; set; }
        public string About { get; set; }
        public string Donation { get; set; }
        public string Success { get; set; }
        public string FilesProcessed { get; set; }
        public string InvalidFile { get; set; }
        public string Developer { get; set; }
        public string FreeText { get; set; }
        public string OpenSourceText { get; set; }
        public string DonationTitle { get; set; }
        public string LitecoinLabel { get; set; }
        public string BtcBep20Label { get; set; }
        public string CopyButton { get; set; }
        public string CopiedMessage { get; set; }
        public string CloseButton { get; set; }
    }
}
