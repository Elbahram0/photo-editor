# Katkıda Bulunma Rehberi

Photo Editor projesine katkıda bulunmak istediğiniz için teşekkürler! 🎉

## Nasıl Katkıda Bulunabilirsiniz?

### 1. Hata Bildirimi
- Issue açın
- Hatayı detaylı açıklayın
- Ekran görüntüsü ekleyin
- Adımları belirtin

### 2. Özellik Önerisi
- Issue açın
- Özelliği detaylı açıklayın
- Kullanım senaryosu verin

### 3. Kod Katkısı

**Adımlar:**
1. Projeyi fork edin
2. Yeni branch oluşturun: `git checkout -b feature/yeni-ozellik`
3. Değişikliklerinizi yapın
4. Test edin
5. Commit edin: `git commit -m 'Yeni özellik eklendi'`
6. Push edin: `git push origin feature/yeni-ozellik`
7. Pull Request açın

### Kod Standartları
- C# coding conventions kullanın
- XAML formatını koruyun
- Yorum satırları ekleyin
- Değişkenler anlamlı isimlendirilmeli

### Test
- Değişikliklerinizi test edin
- Farklı formatlarla deneyin
- Toplu işlem test edin

## İletişim

Sorularınız için: [@El_bahram](https://t.me/El_bahram)

Teşekkürler! ❤️
