# Photo Editor

Modern fotoğraf düzenleme ve format dönüştürme uygulaması.

## Özellikler

- 21+ format desteği (PNG, JPG, WEBP, ICO, HEIC, RAW formatlar)
- Toplu işlem ve boyutlandırma
- Drag & Drop desteği
- Çoklu dil (Türkçe/İngilizce)
- Modern dark tema
- Ücretsiz ve açık kaynak

## Kurulum

[Releases](../../releases) sayfasından setup dosyasını indirin ve çalıştırın.

## Geliştirme

```bash
git clone https://github.com/Elbahram0/photo-editor.git
cd photo-editor
dotnet build PhotoEditor.sln -c Release
```

## Bağış

- Litecoin (LTC): LbUg7FHcdqh6WzmsEWjaGPVBbga2RHvUyT
- Bitcoin BEP20: 0x3fa0982c13522a44ce39439c65501f900408c032

## İletişim

Telegram: https://t.me/El_bahram

## Lisans

MIT License
